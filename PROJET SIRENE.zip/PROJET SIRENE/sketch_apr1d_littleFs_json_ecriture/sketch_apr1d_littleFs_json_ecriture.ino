#include <ArduinoJson.h>
#include <LittleFS.h>

void setup() {
  Serial.begin(115200);

  LittleFS.begin();

  StaticJsonDocument<200> doc;
  doc["duration"] = 10;

  File file = LittleFS.open("/config.json", "w");
  serializeJson(doc, file);
  file.close();

  Serial.println("Sauvegardé !");
}

void loop() {}