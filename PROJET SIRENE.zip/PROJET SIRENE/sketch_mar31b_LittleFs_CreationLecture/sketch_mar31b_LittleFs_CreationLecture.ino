#include "LittleFS.h"
 
void setup() {
  Serial.begin(115200);
  
  if(!LittleFS.begin()){
    Serial.println("An Error has occurred while mounting LittleFS");
    return;
  }
  
File file = LittleFS.open("/test.txt", "w");

if(!file){
  Serial.println("Erreur ouverture fichier");
  return;
}
  
  file.println("Bonjour Luxana !");
  file.println("LittleFS c'est fun");
  file.close();

  Serial.println("Écriture terminée");

  File fileRead = LittleFS.open("/test.txt", "r");
  if(!fileRead){
    Serial.println("Failed to open file for reading");
    return;
  }
  delay(500);
  
  Serial.println("File Content:");
  while(fileRead.available()){
    Serial.write(fileRead.read());
  }
  fileRead.close();

}
 
void loop() {}

