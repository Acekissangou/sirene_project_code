#include <ArduinoJson.h>

void setup() {
  Serial.begin(115200);

  StaticJsonDocument<200> doc;

  doc["duration"] = 10;

  JsonArray monday = doc.createNestedArray("monday");
  monday.add("08:00");
  monday.add("10:00");

  serializeJson(doc, Serial);
}

void loop() {}