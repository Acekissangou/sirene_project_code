#include <ArduinoJson.h>

void setup() {
  Serial.begin(115200);

  String json = "{\"duration\":10,\"monday\":[\"08:00\",\"10:00\"]}";

  StaticJsonDocument<200> doc;

  deserializeJson(doc, json);

  int duration = doc["duration"];

  Serial.println(duration);

  JsonArray monday = doc["monday"];

  for (String time : monday) {
    Serial.println(time);
  }
}

void loop() {}