#include <Wire.h>

#include "RTClib.h"



RTC_DS3231 rtc;



void setup() {

Serial.begin(115200);

if (!rtc.begin()) {

Serial.println("RTC non détecté !");

while (1);

}

rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));

// DateTime customTime(2025, 4, 5, 10, 30, 0); // 5 avril 2025 à 10:30:00

// rtc.adjust(customTime);

}

void loop() {

DateTime now = rtc.now();

Serial.print(now.year(), DEC);

Serial.print('/');

Serial.print(now.month(), DEC);

Serial.print('/');

Serial.print(now.day(), DEC);

Serial.print(' ');

Serial.print(now.hour(), DEC);

Serial.print(':');

Serial.print(now.minute(), DEC);

Serial.print(':');

Serial.println(now.second(), DEC);

Serial.println(now.dayOfTheWeek(), DEC); 

delay(1000);

}

