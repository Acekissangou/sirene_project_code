#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>

const char *ssid = "MECATRONIQUE";
const char *password = "987654321";

IPAddress local_IP(192,168,4,22);
IPAddress gateway(192,168,4,9);
IPAddress subnet(255,255,255,0);

AsyncWebServer server(80);

void setup()
{
  Serial.begin(115200);
  Serial.println();

  // Configuration de l'Access Point
  Serial.print("Configuration AP ... ");
  Serial.println(WiFi.softAPConfig(local_IP, gateway, subnet) ? "Ready" : "Failed");

  Serial.print("Création du WiFi ... ");
  Serial.println(WiFi.softAP(ssid,password) ? "Ready" : "Failed");

  Serial.print("Adresse IP AP : ");
  Serial.println(WiFi.softAPIP());

  // Route web
  server.on("/hello", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(200, "text/plain", "Mon rayon de soleil");
  });

  server.on("/hello1", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", "Mon etoile du matin");
  });

  server.begin();
}

void loop()
{
  Serial.print("Stations connectées : ");
  Serial.println(WiFi.softAPgetStationNum());
  Serial.println(WiFi.softAPIP());
  
  delay(3000);
}