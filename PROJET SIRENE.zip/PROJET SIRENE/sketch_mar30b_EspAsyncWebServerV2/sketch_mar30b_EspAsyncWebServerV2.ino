#include<ESP8266WiFi.h>
#include<ESPAsyncTCP.h>
#include<FS.h>
#include<ESPAsyncWebServer.h>

AsyncWebServer server(80);

const char* ssid = "TASA";
const char* password = "TASA@@#KILI(@.2025$T@S@{}&&)$##..";

void setup() {
  Serial.begin(115200);

  WiFi.begin(ssid, password);

  while(WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connexion au wiFi");
  }

  Serial.println("Connexion établie");
  Serial.print("Adresse IP: ");
  Serial.println(WiFi.localIP());

  server.on("/luxana", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(200, "text/plain", "Luxana ^^");
  });

  server.on("/lux", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(200, "text/plain", "Mon petit soleil ^^");
  });

  server.on("/soleil", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(200, "text/plain", "lumiere");
  });

  server.begin();
}

void loop() {

}