#include <LittleFS.h>

void setup() {
  Serial.begin(115200);

  if (LittleFS.begin()) {
    Serial.println("LittleFS monté");

    LittleFS.format();  // ⚠️ Efface TOUT

    Serial.println("LittleFS vidé !");
  } else {
    Serial.println("Erreur montage LittleFS");
  }
}

void loop() {}