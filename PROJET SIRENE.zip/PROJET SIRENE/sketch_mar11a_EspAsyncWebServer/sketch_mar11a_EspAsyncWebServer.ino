
// Avec l'esp32
// #include<WiFi.h>
// #include<FS.h>
// #include<AsyncTCP.h>
// #include<ESPAsyncWebServer.h>

//Avec l'esp8266
#include<ESP8266WiFi.h>
#include<ESPAsyncTCP.h>
#include<FS.h>
#include<ESPAsyncWebServer.h>

const char* ssid = "ECES  ADMIN SITE 3  5G";
const char* password = "ADMIN@Eces@SARL2025@####.)";
  
AsyncWebServer server(80);

void setup() {

  Serial.begin(115200);

  WiFi.begin(ssid, password);

  while(WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connexion au satané wifi...");
  }

  Serial.println("Connecté !");
  Serial.print("Adresse Ip: ");
  Serial.println(WiFi.localIP());

  server.on("/hello", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", "Salut Lulu");
  });

  server.begin();
}

void loop() {

}