#include <ArduinoJson.h>
#include <LittleFS.h>

void setup() {
  Serial.begin(115200);

  // Initialiser LittleFS
  if (!LittleFS.begin()) {
    Serial.println("Erreur lors du montage de LittleFS");
    return;
  }

  // Vérifier si le fichier existe
  if (!LittleFS.exists("/config.json")) {
    Serial.println("Fichier config.json non trouvé !");
    return;
  }

  // Ouvrir le fichier en lecture
  File file = LittleFS.open("/config.json", "r");
  if (!file) {
    Serial.println("Erreur lors de l'ouverture du fichier");
    return;
  }

  // Créer un document JSON pour stocker les données lues
  StaticJsonDocument<200> doc;

  // Lire et parser le JSON depuis le fichier
  DeserializationError error = deserializeJson(doc, file);
  file.close();

  // Vérifier si le parsing a réussi
  if (error) {
    Serial.print("Erreur de parsing JSON : ");
    Serial.println(error.c_str());
    return;
  }

  // Extraire et afficher les données
  int duration = doc["duration"];
  Serial.print("duration = ");
  Serial.println(duration);


  Serial.println("Lecture terminée !");
}

void loop() {}