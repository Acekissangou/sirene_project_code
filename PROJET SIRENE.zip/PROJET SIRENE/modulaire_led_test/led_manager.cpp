#include "led_manager.h"
#include <Arduino.h>

void initLed() {
  pinMode(LED_BUILTIN, OUTPUT);
  eteindre();
}

void allumer() {
  digitalWrite(LED_BUILTIN, HIGH);
}

void eteindre() {
  digitalWrite(LED_BUILTIN, LOW);
}

void clignoterLed(int duree_ms) {
  allumer();
  delay(duree_ms);
  eteindre();
  delay(duree_ms);
}