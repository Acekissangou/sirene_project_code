#include "led_manager.h"

void setup() {
  Serial.begin(115200);
   initLed();
}

void loop() {
  clignoterLed(300);
}
