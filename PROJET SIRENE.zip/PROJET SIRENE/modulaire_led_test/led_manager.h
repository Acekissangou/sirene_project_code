#ifndef LED_MANAGER_H
#define LED_MANAGER_H

void initLed();
void allumer();
void eteindre();
void clignoterLed(int duree_ms);

#endif