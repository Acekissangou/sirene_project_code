#include <ESP8266WiFi.h>

int stationNumber = 0;
int totalSt = 0;

IPAddress local_IP(192,168,4,22);
IPAddress gateway(192,168,4,9);
IPAddress subnet(255,255,255,0);

const char *ssid = "MabelleLuxana";
const char *password = "Ace+lux12345";

void setup() {
  Serial.begin(115200);
  Serial.println();

  Serial.print("Configuration des paramètres de point d'accès  ");
  Serial.println(WiFi.softAPConfig(local_IP, gateway, subnet) ? "Prêt" : "Echec");

  Serial.print("Création du point d'accès  ");
  Serial.println(WiFi.softAP(ssid, password) ? "Prêt" : "Echec");

  Serial.print("Point d'accès crée avec succès  ");
  Serial.println(WiFi.softAPIP());
}

void loop() {
  stationNumber = WiFi.softAPgetStationNum();
  totalSt = 4 - stationNumber;

  Serial.print("Nombre de station connectés  ");
  Serial.print(totalSt);
  Serial.print(" places disponible ");
  Serial.println(stationNumber);
  delay(1500);
}